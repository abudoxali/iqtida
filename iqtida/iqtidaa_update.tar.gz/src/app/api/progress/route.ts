import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const userId = session.user.id;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);

    const todayProgress = await prisma.userProgress.count({
      where: {
        userId,
        date: { gte: today },
      },
    });

    const weekProgress = await prisma.userProgress.findMany({
      where: {
        userId,
        date: { gte: weekAgo },
      },
      orderBy: { date: "asc" },
    });

    const totalApplied = await prisma.userProgress.count({
      where: { userId },
    });

    const savedCount = await prisma.savedItem.count({
      where: { userId },
    });

    const mostCategory = await prisma.userProgress.groupBy({
      by: ["sunnahPracticeId"],
      where: { userId },
      _count: true,
      orderBy: { _count: { sunnahPracticeId: "desc" } },
      take: 1,
    });

    return NextResponse.json({
      todayCompleted: todayProgress,
      weekProgress,
      totalApplied,
      savedCount,
      mostPracticedCategory: mostCategory[0]?.sunnahPracticeId || null,
    });
  } catch (error) {
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const { sunnahPracticeId, completed } = await req.json();

    if (!sunnahPracticeId) {
      return NextResponse.json({ error: "معرف السنة مطلوب" }, { status: 400 });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const existing = await prisma.userProgress.findFirst({
      where: {
        userId: session.user.id,
        sunnahPracticeId,
        date: today,
      },
    });

    if (existing) {
      await prisma.userProgress.update({
        where: { id: existing.id },
        data: { completed },
      });
    } else {
      await prisma.userProgress.create({
        data: {
          userId: session.user.id,
          sunnahPracticeId,
          date: today,
          completed,
        },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
