import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({
        greeting: "أهلاً بك",
        hijriDate: "",
        gregorianDate: new Date().toLocaleDateString("ar-SA", {
          weekday: "long", year: "numeric", month: "long", day: "numeric",
        }),
        completionPercentage: 0,
        todaySunnahs: 0,
        completedToday: 0,
        streak: 0,
        savedCount: 0,
        totalApplied: 0,
      });
    }

    const userId = session.user.id;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const hour = today.getHours();
    const greeting = hour < 12 ? "صباح الخير" : hour < 17 ? "نهارك مبارك" : "مساء الخير";

    const todaySunnahs = await prisma.sunnahPractice.count({
      where: { published: true },
    });

    const completedToday = await prisma.userProgress.count({
      where: { userId, date: { gte: today }, completed: true },
    });

    const totalApplied = await prisma.userProgress.count({
      where: { userId },
    });

    const savedCount = await prisma.savedItem.count({
      where: { userId },
    });

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { streak: true },
    });

    return NextResponse.json({
      greeting: `${greeting}، ${session.user.name || ""}`,
      hijriDate: "",
      gregorianDate: new Date().toLocaleDateString("ar-SA", {
        weekday: "long", year: "numeric", month: "long", day: "numeric",
      }),
      completionPercentage: todaySunnahs > 0 ? Math.round((completedToday / todaySunnahs) * 100) : 0,
      todaySunnahs,
      completedToday,
      streak: user?.streak || 0,
      savedCount,
      totalApplied,
    });
  } catch (error) {
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
