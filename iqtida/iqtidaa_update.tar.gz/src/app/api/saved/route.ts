import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const items = await prisma.savedItem.findMany({
      where: { userId: session.user.id },
      include: {
        hadith: true,
        sunnahPractice: true,
        answer: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ items });
  } catch (error) {
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
    }

    const { type, hadithId, sunnahPracticeId, answerId } = await req.json();
    const userId = session.user.id;

    const existing = await prisma.savedItem.findFirst({
      where: { userId, type, hadithId, sunnahPracticeId, answerId },
    });

    if (existing) {
      await prisma.savedItem.delete({ where: { id: existing.id } });
      return NextResponse.json({ saved: false });
    }

    await prisma.savedItem.create({
      data: { userId, type, hadithId, sunnahPracticeId, answerId },
    });

    return NextResponse.json({ saved: true });
  } catch (error) {
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
