"use client";

import { useState, useEffect, useMemo } from "react";
import { useSession } from "next-auth/react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Clock, Search, BookOpen, Flame, Sparkles, ArrowLeft,
  Sun, Moon, Sunrise, Coffee, Users, Briefcase, Home,
  Heart, CheckCircle2, Star, Loader2, AlertCircle, BookmarkCheck
} from "lucide-react";
import Link from "next/link";
import { GENERAL_DISCLAIMER } from "@/lib/constants";

interface SunnahItem {
  id: string;
  title: string;
  description: string;
  category: string;
  dayMoment: string;
  evidenceStatus: string;
  difficulty: string;
  estimatedTime?: string;
  practicalSteps?: string;
  commonMistakes?: string;
  hadith?: {
    id: string;
    arabicText: string;
    sourceBook: string;
    grade: string;
  };
}

const SUNNAH_CATEGORIES = [
  { id: "WORSHIP", label: "عبادة", description: "السنن التعبدية والصلوات", icon: BookOpen },
  { id: "HABIT", label: "عادة", description: "العادات والآداب النبوية اليومية", icon: Clock },
  { id: "MANNERS", label: "أدب", description: "مكارم الأخلاق وحسن المعاملة", icon: Users },
  { id: "REMEMBRANCE", label: "أذكار", description: "الأذكار اليومية والأدعية الثابتة", icon: Sparkles },
  { id: "TRANSACTION", label: "معاملة", description: "سنن البيع والتعامل والحقوق", icon: Briefcase },
];

export default function DashboardPage() {
  const { data: session } = useSession();
  const searchParams = useSearchParams();
  const catFilter = searchParams.get("cat");

  const [stats, setStats] = useState<any>({
    greeting: "أهلاً بك",
    hijriDate: "",
    gregorianDate: "",
    completionPercentage: 0,
    todaySunnahs: 0,
    completedToday: 0,
    streak: 0,
    savedCount: 0,
    totalApplied: 0,
  });

  const [sunnahs, setSunnahs] = useState<SunnahItem[]>([]);
  const [completed, setCompleted] = useState<string[]>([]);
  const [saved, setSaved] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(catFilter);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const today = new Date();
  const hour = today.getHours();

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        // 1. Fetch dashboard stats
        const statsRes = await fetch("/api/dashboard");
        const statsData = await statsRes.json();
        if (statsData && !statsData.error) {
          setStats(statsData);
        }

        // 2. Fetch sunnah practices
        const sunnahsRes = await fetch("/api/sunnah");
        const sunnahsData = await sunnahsRes.json();
        if (sunnahsData.sunnahs) {
          setSunnahs(sunnahsData.sunnahs);
        }

        // 3. Fetch completed progress
        const progressRes = await fetch("/api/progress");
        const progressData = await progressRes.json();
        if (progressData.weekProgress) {
          const todayStr = new Date().toISOString().slice(0, 10);
          const todayCompleted = progressData.weekProgress
            .filter((p: any) => p.date.startsWith(todayStr) && p.completed)
            .map((p: any) => p.sunnahPracticeId);
          setCompleted(todayCompleted);
        }

        // 4. Fetch saved items
        const savedRes = await fetch("/api/saved");
        const savedData = await savedRes.json();
        if (savedData.items) {
          setSaved(savedData.items.map((i: any) => i.sunnahPracticeId).filter(Boolean));
        }
      } catch (err) {
        setError("فشل في تحميل بيانات لوحة التحكم، يرجى المحاولة لاحقاً.");
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  const toggleComplete = async (id: string) => {
    const isDone = completed.includes(id);
    const updated = isDone ? completed.filter((c) => c !== id) : [...completed, id];
    setCompleted(updated);

    // Optimistically update local stats
    const newCompletedToday = isDone ? Math.max(0, stats.completedToday - 1) : stats.completedToday + 1;
    const newTotalApplied = isDone ? Math.max(0, stats.totalApplied - 1) : stats.totalApplied + 1;
    const newPercent = stats.todaySunnahs > 0 ? Math.round((newCompletedToday / stats.todaySunnahs) * 100) : 0;

    setStats((prev: any) => ({
      ...prev,
      completedToday: newCompletedToday,
      totalApplied: newTotalApplied,
      completionPercentage: newPercent,
    }));

    try {
      await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sunnahPracticeId: id, completed: !isDone }),
      });
    } catch {
      // Revert if error
      setCompleted(completed);
    }
  };

  const toggleSave = async (id: string) => {
    const isSaved = saved.includes(id);
    const updated = isSaved ? saved.filter((s) => s !== id) : [...saved, id];
    setSaved(updated);

    // Optimistically update savedCount
    const newSavedCount = isSaved ? Math.max(0, stats.savedCount - 1) : stats.savedCount + 1;
    setStats((prev: any) => ({
      ...prev,
      savedCount: newSavedCount,
    }));

    try {
      await fetch("/api/saved", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "SUNNAH", sunnahPracticeId: id }),
      });
    } catch {
      setSaved(saved);
    }
  };

  const currentTimeSunnahs = useMemo(() => {
    if (hour < 6) return sunnahs.filter((s) => s.dayMoment === "BEFORE_SLEEP" || s.dayMoment === "NIGHT_WAKE");
    if (hour < 9) return sunnahs.filter((s) => s.dayMoment === "WAKE_UP" || s.dayMoment === "MORNING" || s.dayMoment === "WUDHU_PRAYER");
    if (hour < 12) return sunnahs.filter((s) => s.dayMoment === "MORNING" || s.dayMoment === "WUDHU_PRAYER");
    if (hour < 15) return sunnahs.filter((s) => s.dayMoment === "FOOD_DRINK" || s.dayMoment === "INTERACTION" || s.dayMoment === "WORK_STUDY");
    if (hour < 18) return sunnahs.filter((s) => s.dayMoment === "EVENING" || s.dayMoment === "FOOD_DRINK" || s.dayMoment === "LEAVING_HOME");
    if (hour < 21) return sunnahs.filter((s) => s.dayMoment === "EVENING" || s.dayMoment === "INTERACTION");
    return sunnahs.filter((s) => s.dayMoment === "BEFORE_SLEEP");
  }, [hour, sunnahs]);

  const filteredSunnahs = useMemo(() => {
    if (!selectedCategory) return currentTimeSunnahs.slice(0, 4);
    return sunnahs.filter((s) => s.category === selectedCategory);
  }, [selectedCategory, currentTimeSunnahs, sunnahs]);

  const quickActions = [
    { href: "/today", label: "يومي على السنة", icon: Clock, desc: "سنن يومك مرتبة" },
    { href: "/ask", label: "اسأل عن السنة", icon: Search, desc: "هل كان النبي ﷺ؟" },
    { href: "/library", label: "أقسام السنة", icon: BookOpen, desc: "جميع السنن" },
    { href: "/saved", label: "المفضلة", icon: Heart, desc: "سنني المحفوظة" },
  ];

  const getTimeLabel = () => {
    if (hour < 6) return "قيام الليل والتهجد";
    if (hour < 9) return "الاستيقاظ والصباح";
    if (hour < 12) return "الضحى والعبادة";
    if (hour < 15) return "الطعام والتعامل";
    if (hour < 18) return "العصر والمساء";
    if (hour < 21) return "أذكار المساء";
    return "قبل النوم";
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center" dir="rtl">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">جاري تحميل لوحة التحكم...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-md mx-auto py-12 text-center" dir="rtl">
        <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <h3 className="text-lg font-bold">خطأ في تحميل البيانات</h3>
        <p className="text-sm text-muted-foreground mt-2">{error}</p>
        <Button className="mt-4 gold-gradient text-white" onClick={() => window.location.reload()}>إعادة المحاولة</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto" dir="rtl">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold">
              {stats.greeting || "أهلاً بك"}
            </h1>
            <p className="text-sm text-muted-foreground/60 mt-1">{stats.gregorianDate || today.toLocaleDateString("ar-SA", {
              weekday: "long", year: "numeric", month: "long", day: "numeric",
            })}</p>
          </div>
          <Link
            href="/today"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl gold-gradient text-white text-sm font-medium shadow-sm hover:gold-glow transition-all"
          >
            <Sparkles className="h-4 w-4" />
            ابدأ يومك على السنة
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quickActions.map((action) => (
            <Link key={action.href} href={action.href}>
              <Card className="group border gold-border bg-white/80 dark:bg-card/50 backdrop-blur-sm transition-all duration-300 hover:gold-shadow hover:-translate-y-0.5 cursor-pointer">
                <CardContent className="flex flex-col items-center gap-2 p-5 text-center">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl gold-gradient-soft dark:bg-accent/10 group-hover:scale-110 transition-transform">
                    <action.icon className="h-5 w-5 text-accent" />
                  </div>
                  <span className="text-sm font-bold">{action.label}</span>
                  <span className="text-xs text-muted-foreground/60">{action.desc}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </motion.div>

      {/* Main Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Sunnah Now */}
          {!selectedCategory && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <Card className="border gold-border bg-white/80 dark:bg-card/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Clock className="h-5 w-5 text-accent" />
                    سنة الآن | {getTimeLabel()}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {currentTimeSunnahs.length > 0 ? (
                    <div className="space-y-3">
                      {currentTimeSunnahs.slice(0, 3).map((item) => (
                        <div key={item.id} className="rounded-xl gold-gradient-soft dark:bg-accent/5 border gold-border p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="space-y-2 flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge variant="outline" className="emerald-badge text-xs">
                                  {item.evidenceStatus === "SAHIH" ? "ثابت وصحيح" : "حسن"}
                                </Badge>
                                <Badge variant="secondary" className="text-xs">{item.difficulty === "easy" ? "سهل" : item.difficulty === "medium" ? "متوسط" : "صعب"}</Badge>
                              </div>
                              <h3 className="font-bold">{item.title}</h3>
                              <p className="text-sm text-muted-foreground/80 line-clamp-2">{item.description}</p>
                              {item.hadith && (
                                <p className="text-xs text-muted-foreground/50">📖 {item.hadith.sourceBook}</p>
                              )}
                              <div className="flex gap-2 pt-1">
                                <Button
                                  size="sm"
                                  className={`text-xs gap-1 ${completed.includes(item.id) ? "bg-emerald-500 text-white" : "gold-gradient text-white shadow-sm"}`}
                                  onClick={() => toggleComplete(item.id)}
                                >
                                  <CheckCircle2 className="h-3.5 w-3.5" />
                                  {completed.includes(item.id) ? "✓ طبّقت" : "طبّقت"}
                                </Button>
                                <Button size="sm" variant="outline" className="text-xs border-accent/20 text-accent" asChild>
                                  <Link href={`/library/${item.id}`}>
                                    عرض التفاصيل
                                  </Link>
                                </Button>
                              </div>
                            </div>
                            <button
                              onClick={() => toggleSave(item.id)}
                              className={`shrink-0 p-1.5 rounded-lg transition-colors ${saved.includes(item.id) ? "text-red-500" : "text-muted-foreground/30 hover:text-red-400"}`}
                            >
                              <Heart className={`h-4.5 w-4.5 ${saved.includes(item.id) ? "fill-red-500" : ""}`} />
                            </button>
                          </div>
                        </div>
                      ))}
                      <div className="text-center">
                        <Button variant="link" className="text-accent" asChild>
                          <Link href="/today">
                            عرض جدول اليوم كاملاً
                            <ArrowLeft className="mr-1 h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground/60 text-center py-6">
                      لا توجد سنن محددة لهذا الوقت. تصفح جميع السنن في المكتبة.
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Categories */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
            <Card className="border gold-border bg-white/80 dark:bg-card/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <BookOpen className="h-5 w-5 text-accent" />
                  {selectedCategory ? `قسم: ${SUNNAH_CATEGORIES.find(c => c.id === selectedCategory)?.label || selectedCategory}` : "أقسام السنة"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedCategory ? (
                  <div className="space-y-3">
                    {filteredSunnahs.map((item) => (
                      <SunnahCardItem
                        key={item.id}
                        item={item}
                        completed={completed.includes(item.id)}
                        saved={saved.includes(item.id)}
                        onToggle={toggleComplete}
                        onSave={toggleSave}
                      />
                    ))}
                    <div className="text-center pt-2">
                      <Button variant="ghost" size="sm" onClick={() => setSelectedCategory(null)}>
                        عرض جميع الأقسام
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {SUNNAH_CATEGORIES.map((cat) => {
                      const Icon = cat.icon;
                      return (
                        <button
                          key={cat.id}
                          onClick={() => setSelectedCategory(cat.id)}
                          className="group flex items-center gap-3 rounded-xl border gold-border bg-white/50 dark:bg-card/30 p-4 transition-all duration-200 hover:gold-shadow hover:-translate-y-0.5 text-right"
                        >
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl gold-gradient-soft dark:bg-accent/10">
                            <Icon className="h-5 w-5 text-accent" />
                          </div>
                          <div className="min-w-0">
                            <h4 className="font-bold text-sm">{cat.label}</h4>
                            <p className="text-xs text-muted-foreground/60">{cat.description}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Sidebar */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="space-y-4">
          <Card className="border gold-border bg-white/80 dark:bg-card/50">
            <CardContent className="flex items-center gap-4 p-5">
              <div className="flex h-14 w-14 items-center justify-center rounded-xl gold-gradient text-white shadow-md">
                <Flame className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalApplied || 0}</p>
                <p className="text-xs text-muted-foreground/60">سنة طبّقتها كلياً</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border gold-border bg-white/80 dark:bg-card/50">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-bold">إنجاز اليوم</span>
                <span className="text-sm text-muted-foreground/60">{stats.completionPercentage || 0}%</span>
              </div>
              <Progress value={stats.completionPercentage || 0} className="h-2.5 bg-amber-100 dark:bg-secondary rounded-full [&>div]:gold-gradient [&>div]:rounded-full" />
              <p className="text-xs text-muted-foreground/50 mt-2">{stats.completedToday || 0} سنة طبّقتها اليوم من أصل {stats.todaySunnahs || 0}</p>
            </CardContent>
          </Card>

          <Card className="border gold-border bg-white/80 dark:bg-card/50">
            <CardContent className="p-5 space-y-4">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Search className="h-4 w-4 text-accent" />
                هل ثبَت عن النبي ﷺ؟
              </h3>
              <div className="flex gap-2">
                <Button className="flex-1 gold-gradient text-white shadow-sm text-xs" asChild>
                  <Link href="/ask">
                    <Search className="h-4 w-4 ml-1" />
                    اسأل الآن
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border gold-border bg-white/80 dark:bg-card/50">
            <CardContent className="p-5">
              <h3 className="text-sm font-bold flex items-center gap-2 mb-3">
                <Star className="h-4 w-4 text-accent" />
                روابط سريعة
              </h3>
              <div className="space-y-2">
                {[
                  { href: "/saved", label: "المفضلة", icon: Heart },
                  { href: "/sources", label: "المصادر", icon: BookOpen },
                  { href: "/progress", label: "تقدّمي", icon: Flame },
                ].map((link) => (
                  <Link key={link.href} href={link.href} className="flex items-center gap-2 text-sm text-muted-foreground/70 hover:text-accent transition-colors py-1">
                    <link.icon className="h-4 w-4" />
                    {link.label}
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        className="text-xs text-muted-foreground/40 text-center">
        {GENERAL_DISCLAIMER}
      </motion.p>
    </div>
  );
}

function SunnahCardItem({
  item,
  completed,
  saved,
  onToggle,
  onSave
}: {
  item: SunnahItem;
  completed: boolean;
  saved: boolean;
  onToggle: (id: string) => void;
  onSave: (id: string) => void;
}) {
  return (
    <div className={`rounded-xl border p-4 transition-all duration-200 ${completed ? "border-emerald-300/50 bg-emerald-50/50 dark:bg-emerald-500/5" : "border gold-border bg-white/50 dark:bg-card/30 hover:gold-shadow"}`}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <Badge variant="outline" className="emerald-badge text-[10px]">{item.evidenceStatus === "SAHIH" ? "ثابت وصحيح" : "حسن"}</Badge>
            <Badge variant="secondary" className="text-[10px]">{item.difficulty === "easy" ? "سهل" : "متوسط"}</Badge>
            {item.estimatedTime && (
              <span className="text-[10px] text-muted-foreground/50">{item.estimatedTime}</span>
            )}
          </div>
          <h4 className="font-bold text-sm">{item.title}</h4>
          <p className="text-xs text-muted-foreground/70 mt-1 line-clamp-2">{item.description}</p>
        </div>
        <button
          onClick={() => onSave(item.id)}
          className={`shrink-0 p-1 rounded-lg transition-colors ${saved ? "text-red-500" : "text-muted-foreground/30 hover:text-red-400"}`}
        >
          <Heart className={`h-4 w-4 ${saved ? "fill-red-500" : ""}`} />
        </button>
      </div>
      <div className="flex gap-2 mt-2">
        <Button size="sm" variant={completed ? "default" : "outline"}
          className={`h-8 text-xs gap-1 ${completed ? "bg-emerald-500 text-white" : "border-emerald-300/50 text-emerald-700 dark:text-emerald-400"}`}
          onClick={() => onToggle(item.id)}>
          <CheckCircle2 className="h-3.5 w-3.5" />
          {completed ? "✓ طبّقت" : "طبّقت"}
        </Button>
        <Button size="sm" variant="ghost" className="h-8 text-xs" asChild>
          <Link href={`/library/${item.id}`}>التفاصيل</Link>
        </Button>
      </div>
    </div>
  );
}
